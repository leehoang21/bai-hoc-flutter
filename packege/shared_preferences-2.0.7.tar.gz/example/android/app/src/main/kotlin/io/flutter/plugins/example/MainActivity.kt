package io.flutter.plugins.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
